using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spitter : MonoBehaviour
{
    //[SerializeField] private KillPlayer _bullet;
    //[SerializeField] private float _cooldown;
    //private bool _canShoot = true;

    //private Vector3 _bulletPosition;
    //private Quaternion _bulletRotation;


    //private void Start()
    //{
    //    _bulletPosition = _bullet.transform.position;
    //    _bulletRotation = _bullet.transform.rotation;

    //}



    //private void FixedUpdate()
    //{
    //    if (_canShoot)
    //    {
    //        StartCoroutine("Shoot");
    //    }


    //}

    //IEnumerator Shoot()
    //{
    //    _canShoot = false;
    //    _bullet.transform.position = _bulletPosition;
    //    _bullet.transform.rotation = _bulletRotation;


    //    yield return new WaitForSeconds(_cooldown);
    //    _canShoot = true;
    //}

}
